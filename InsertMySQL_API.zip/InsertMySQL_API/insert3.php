<?php
$servername = "localhost";
$username = "id937416_root";
$password = "123456";
$dbname = "id937416_eventplus";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$name=$_GET['name'];
$score=$_GET['score'];
	//echo "Name: " . $name . "; Score: " .$score;

$sql = "INSERT INTO test1 (name, score)
VALUES ('$name', '$score')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
//print(json_encode($flag));
$conn->close();
?> 